# Networking & VLAN notes
